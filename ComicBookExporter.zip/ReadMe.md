# Comic Book Exporter
## What does it do
+ Takes your wishlist from instocktrades and creates a downloadable csv file, with the price in USD for the total cost of your wishlist.
## How to Use
+ Simply install the extension form the chrome webstore, and then go to a wishlist; for example, https://www.instocktrades.com/wishlists/d9d86e8bc3bc4f2d9f1dcaf98a4bc3 
then next to the 'Wishlists' text near the top of the screen there should be a link called '(Download Wishlist)', click that and your wishlist will be saved to your downloads folder.
##Why
+ I was annoyed by the fact that you cannot easily see how much buying a collection of comics is, as adding the comic to your cart takes it away from your wishlist.

